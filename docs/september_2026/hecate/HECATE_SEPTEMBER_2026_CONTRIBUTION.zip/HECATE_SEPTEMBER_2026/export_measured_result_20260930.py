"""Export an allowlisted numeric view of the existing result and a source-bound plot."""
from pathlib import Path
import datetime
import hashlib
import json
import os
os.environ['OMP_NUM_THREADS'] = '2'
os.environ['OPENBLAS_NUM_THREADS'] = '2'
os.environ['MKL_NUM_THREADS'] = '2'
import psutil
assert psutil.virtual_memory().available >= 10 * 2**30
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'CONTROL_CLI_FRESH_PROCESS_256_20260930/ACTUAL_CLI_PARITY_RESOURCE_RECEIPT.json'
SHA = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert SHA(SOURCE) == '3fc2bbbdfe65a8c7f3b304ef9146b9c4165a920ed6b948c5e79e1fd878521426'
d = json.loads(SOURCE.read_text())
out = ROOT / 'PUBLIC_MEASURED_RESULT_20260930.json'
png = ROOT / 'ACTUAL_CLI_COMPARISON_20260930.png'
manifest = ROOT / 'PUBLIC_RELEASE_FILE_MANIFEST_20260930.json'
assert not any(p.exists() for p in (out, png, manifest))
result = {k: d[k] for k in ('state','created_utc','finished_utc','scope','input_shape',
    'target_inference','prelaunch_temperature_rule','pairs','median_process_seconds',
    'elapsed_reduction_percent','owned_workers_stopped','resource_monitor_errors',
    'resource_sample_count','resources')}
result['source_receipt_sha256'] = SHA(SOURCE)
result['source_harness_sha256'] = d['script_sha256_at_start']
result['export_script_sha256'] = SHA(Path(__file__))
result['exported_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
result['identities'] = [
    {'role': role, 'sha256': value} for role, value in zip(
        ['prepared_input_npy','checkpoint','baseline_provider','candidate_provider','shared_helper'],
        d['identities'].values())]
result['runs'] = []
for r in d['runs']:
    w = r['worker']
    row = {k:r[k] for k in ('mode','repeat','elapsed_process_seconds','exit_code','owned_worker_stopped')}
    row['start_temperature_c'] = r['start_gpu']['temperature_c']
    row['worker'] = {k:w[k] for k in ('state','features_logits_calls','exact_hook_pause_seconds',
                                      'cli_main_seconds','cuda_peak_allocated_mib','cuda_peak_reserved_mib')}
    result['runs'].append(row)
result['export_policy'] = 'Numeric allowlist; removes local paths, PIDs and per-file output manifests. Original receipt preserved. No raw arrays or target data.'
result['claim_limits'] = ['One exposed PHerc0139 field and one GPU',
    'Paired 2D+3D implementation equality, not ink accuracy',
    'Resource hooks and identity checks included; raw resampling and UI transport excluded',
    'Fresh process does not imply cold file cache', 'No whole-scroll or 2D-only speed claim']
with out.open('x', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
    f.write('\n')

fig, ax = plt.subplots(figsize=(11, 6.3), dpi=160)
fig.subplots_adjust(left=.09, right=.97, bottom=.28, top=.78)
for mode, color, dx, label in [('baseline','#747e8c',-.18,'Pinned provider CLI'),
                               ('candidate','#147d71',.18,'Shared-feature CLI')]:
    runs = [r for r in result['runs'] if r['mode']==mode]
    values = [r['elapsed_process_seconds'] for r in runs]
    xs = [r['repeat']+dx for r in runs]
    bars=ax.bar(xs, values, width=.32, color=color, label=label)
    ax.bar_label(bars, labels=[f'{v:.2f}s' for v in values], padding=4, fontsize=10)
ax.set_xticks([1,2,3],['Pair 1','Pair 2','Pair 3'])
ax.set_ylim(0,22)
ax.set_ylabel('Process launch to exit (seconds)')
ax.spines[['top','right']].set_visible(False)
ax.legend(frameon=False, loc='upper right')
fig.suptitle('Hecate paired output: identical predictions, less elapsed time', fontsize=16, y=.95)
fig.text(.09,.84,'35.01% lower median time  |  17.8357s → 11.5913s  |  98 → 49 feature calls',fontsize=12)
fig.text(.09,.18,'All 65,536 2D pixels + 1,048,576 3D voxels match in every pair.',fontsize=11)
fig.text(.09,.135,'One exposed PHerc0139 field • 16×256×256 • GTX 1660 Ti • FP32 • batch 1',fontsize=10)
fig.text(.09,.09,'Starts 52–54°C; peak 68°C; no cooling pause. Guardian hooks included; OS cache not cleared.',fontsize=9)
fig.text(.09,.048,'Engineering comparison only. No claim of improved ink accuracy, unread text, or whole-scroll speed.',fontsize=9)
fig.savefig(png)
plt.close(fig)
names = ['PROVIDER_CANDIDATE.patch','PROVIDER_TESTS.patch','hecate.py',
         'hecate_shared_output.py','test_hecate_shared_output.py','PUBLIC_REVIEW_DRAFT.md',
         out.name,png.name,Path(__file__).name]
payload = {'state':'LOCAL_REVIEW_ONLY_NOT_PUBLISHED', 'created_utc':result['exported_utc'],
           'source_receipt_sha256':SHA(SOURCE), 'files':[
               {'name':name,'sha256':SHA(ROOT/name),'bytes':(ROOT/name).stat().st_size} for name in names]}
with manifest.open('x',encoding='utf-8') as f:
    json.dump(payload,f,indent=2)
    f.write('\n')
print(json.dumps({'result':str(out),'plot':str(png),'manifest':str(manifest),
                  'result_sha256':SHA(out),'plot_sha256':SHA(png),'file_count':len(names)}))
