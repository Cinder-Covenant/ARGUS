"""Parity tests for Hecate's shared 2D/3D feature projection."""
from __future__ import annotations

import torch
import torch.nn.functional as F
import numpy as np
from torch import nn

from hecate_shared_output import predict_both, shared_logits


class _Collapse(nn.Module):
    def __init__(self):
        super().__init__()
        self.attn_conv = nn.Conv3d(1, 1, 1, bias=True)


class _Decoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.depth_collapse = _Collapse()


class _Canonical(nn.Module):
    def __init__(self):
        super().__init__()
        self.decoder = _Decoder()


class _FakeHecate(nn.Module):
    def __init__(self, margin=0, xy_stride=1):
        super().__init__()
        self.anchor = nn.Parameter(torch.zeros(()))
        self.canonical = _Canonical()
        self.depth_coordinate_scale = nn.Parameter(torch.tensor(0.17))
        self.margin = margin
        self.xy_stride = xy_stride
        self.divisor = 255.0
        self.patch_size = (6, 8, 8)
        self.feature_calls = 0

    def features_logits(self, image):
        self.feature_calls += 1
        features = image[:, :, self.margin:image.shape[2] - self.margin]
        if self.xy_stride > 1:
            features = F.avg_pool3d(
                features, (1, self.xy_stride, self.xy_stride),
                stride=(1, self.xy_stride, self.xy_stride),
            )
        logits = features * 0.73 + 0.11
        return features, logits

    def forward(self, image, valid=None):
        features, logits = self.features_logits(image)
        scores = self.canonical.decoder.depth_collapse.attn_conv(features).float()
        half = scores.shape[2] // 2
        z = (torch.arange(scores.shape[2], device=scores.device, dtype=torch.float32) - half) / half
        scores = scores + self.depth_coordinate_scale * z.view(1, 1, -1, 1, 1)
        if valid is None:
            support = torch.ones_like(logits, dtype=torch.bool)
        else:
            support = F.max_pool3d(
                valid[:, :, self.margin:image.shape[2] - self.margin].float(),
                (1, self.xy_stride, self.xy_stride),
            ).bool()
        weights = scores.masked_fill(~support, -1e4).softmax(2) * support
        weights = weights / weights.sum(2, keepdim=True).clamp_min(1e-8)
        probability = F.interpolate(
            (weights * logits).sum(2).sigmoid(), size=image.shape[-2:],
            mode="bilinear", align_corners=False,
        )
        eps = torch.finfo(torch.float32).eps
        return torch.logit(probability.clamp(eps, 1 - eps))

    def forward_3d(self, image):
        _, logits = self.features_logits(image)
        full = F.interpolate(
            logits, size=(image.shape[2] - 2 * self.margin, *image.shape[-2:]),
            mode="trilinear", align_corners=False,
        )
        return F.pad(full, (0, 0, 0, 0, self.margin, self.margin), value=-20.0)


def test_shared_heads_match_separate_pinned_head_math_without_duplicate_features():
    torch.manual_seed(7)
    model = _FakeHecate().eval()
    image = torch.rand(2, 1, 6, 12, 10)
    valid = torch.ones_like(image, dtype=torch.bool)
    valid[:, :, :, :2, :3] = False

    expected_2d = model(image, valid)
    expected_3d = model.forward_3d(image)
    separate_calls = model.feature_calls
    assert separate_calls == 2

    actual_2d, actual_3d = shared_logits(model, image, valid)
    assert model.feature_calls - separate_calls == 1
    assert torch.equal(actual_2d, expected_2d)
    assert torch.equal(actual_3d, expected_3d)


def test_shared_heads_preserve_two_point_four_micron_margin_padding():
    torch.manual_seed(11)
    model = _FakeHecate(margin=1, xy_stride=2).eval()
    image = torch.rand(1, 1, 6, 12, 10)
    valid = torch.ones_like(image, dtype=torch.bool)
    valid[:, :, :, :2, :3] = False

    expected_2d = model(image, valid)
    expected_3d = model.forward_3d(image)
    actual_2d, actual_3d = shared_logits(model, image, valid)
    assert torch.equal(actual_2d, expected_2d)
    assert torch.equal(actual_3d, expected_3d)
    assert torch.all(actual_3d[:, :, 0] == -20.0)
    assert torch.all(actual_3d[:, :, -1] == -20.0)


@torch.inference_mode()
def _stock_predict(model, volume, output, *, reverse, stride, three_d):
    """Small CPU reference matching the pinned provider's separate-head tiler."""
    d, patch, _ = model.patch_size
    depth, height, width = volume.shape
    z0 = depth // 2 - d // 2
    zs = slice(depth - z0 - d, depth - z0) if reverse else slice(z0, z0 + d)
    window = torch.hann_window(patch, periodic=False)
    window = window[:, None] * window[None, :]
    window = (window / window.max().clamp_min(torch.finfo(torch.float32).eps)).clamp_min(0.001)
    numerator = torch.zeros((d, height, width) if three_d else (height, width), dtype=torch.float32)
    denominator = torch.zeros((height, width), dtype=torch.float32)
    starts_y = list(range(0, max(0, height - patch), stride)) + [max(0, height - patch)]
    starts_x = list(range(0, max(0, width - patch), stride)) + [max(0, width - patch)]
    for y in starts_y:
        for x in starts_x:
            ph, pw = min(patch, height - y), min(patch, width - x)
            denominator[y:y + ph, x:x + pw] += window[:ph, :pw]
            raw = np.asarray(volume[zs, y:y + ph, x:x + pw])
            if reverse:
                raw = raw[::-1]
            if not raw.any():
                continue
            padded = np.zeros((d, patch, patch), dtype=np.uint8)
            padded[:, :ph, :pw] = raw
            support = torch.from_numpy(padded[None]).any(1)
            image = torch.from_numpy(padded.astype(np.float32)[None, None] / model.divisor)
            valid = support[:, None, None].expand(-1, 1, d, -1, -1)
            logits = model.forward_3d(image) if three_d else model(image, valid)
            probability = logits.float().sigmoid()[:, 0]
            if three_d:
                weighted = probability * support[:, None] * window
                numerator[:, y:y + ph, x:x + pw] += weighted[0, :, :ph, :pw]
            else:
                weighted = probability * support * window
                numerator[y:y + ph, x:x + pw] += weighted[0, :ph, :pw]
    if three_d and model.margin:
        numerator[:model.margin] = 0
        numerator[-model.margin:] = 0
    probability = numerator / (denominator[None] if three_d else denominator)
    values = torch.round(probability.clamp(0, 1) * 255).to(torch.uint8).numpy()
    if three_d:
        output[zs] = values[::-1] if reverse else values
    else:
        output[:] = values


def test_tiled_outputs_match_two_stock_passes_and_skip_blank_tiles():
    torch.manual_seed(19)
    model = _FakeHecate().eval()
    volume = np.zeros((6, 13, 15), dtype=np.uint8)
    volume[:, :7, :7] = np.random.default_rng(19).integers(1, 255, size=(6, 7, 7), dtype=np.uint8)
    expected_2d = np.zeros((13, 15), dtype=np.uint8)
    expected_3d = np.zeros((6, 13, 15), dtype=np.uint8)
    _stock_predict(model, volume, expected_2d, reverse=False, stride=4, three_d=False)
    _stock_predict(model, volume, expected_3d, reverse=False, stride=4, three_d=True)

    actual_2d = np.zeros_like(expected_2d)
    actual_3d = np.zeros_like(expected_3d)
    result = predict_both(model, volume, actual_2d, actual_3d, stride=4, batch_size=1)
    assert result["tile_count"] == 9
    assert result["blank_tiles_skipped"] > 0
    assert np.array_equal(actual_2d, expected_2d)
    assert np.array_equal(actual_3d, expected_3d)


def test_center_depth_crop_and_reverse_order_match_two_stock_passes():
    """Longer inputs select the centered model-depth window in either direction."""
    for reverse in (False, True):
        torch.manual_seed(31)
        model = _FakeHecate().eval()
        rng = np.random.default_rng(31)
        volume = rng.integers(0, 256, size=(9, 11, 13), dtype=np.uint8)
        expected_2d = np.zeros((11, 13), dtype=np.uint8)
        expected_3d = np.zeros((9, 11, 13), dtype=np.uint8)
        _stock_predict(model, volume, expected_2d, reverse=reverse, stride=4, three_d=False)
        _stock_predict(model, volume, expected_3d, reverse=reverse, stride=4, three_d=True)

        actual_2d = np.zeros_like(expected_2d)
        actual_3d = np.zeros_like(expected_3d)
        result = predict_both(
            model, volume, actual_2d, actual_3d, reverse=reverse, stride=4, batch_size=1,
        )
        z0 = volume.shape[0] // 2 - model.patch_size[0] // 2
        selected_z0 = volume.shape[0] - z0 - model.patch_size[0] if reverse else z0
        assert result["tile_count"] == 6
        assert np.array_equal(actual_2d, expected_2d)
        assert np.array_equal(actual_3d, expected_3d)
        assert np.all(actual_3d[:selected_z0] == 0)
        assert np.all(actual_3d[selected_z0 + model.patch_size[0]:] == 0)
        assert np.any(actual_3d[selected_z0:selected_z0 + model.patch_size[0]] > 0)
